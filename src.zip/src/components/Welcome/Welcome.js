import './Welcome.css';
import Routes from '../../routes';
import SideNav from '../SideNav/SideNav';

function Welcome() {
  return (
    <div  id="wrapper">
         <SideNav/>
          <Routes/>
      </div>
    );
}

export default Welcome;
