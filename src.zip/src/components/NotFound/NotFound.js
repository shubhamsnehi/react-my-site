import './NotFound.css';
import SideNav from '../SideNav/SideNav';

function NotFound() {
  return (
    
    <div id="wrapper">
    <SideNav/>
    <div id="content-wrapper" class="d-flex flex-column">
      <div class="container-fluid">
          <h2>Not Found 404</h2>
      </div>
    </div>
  </div>
  
    );
}

export default NotFound;
